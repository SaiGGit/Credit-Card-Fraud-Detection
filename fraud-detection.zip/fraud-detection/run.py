from app import create_app
from app.database import init_db

app = create_app()

@app.before_first_request
def initialize_db():
    init_db()

if __name__ == '__main__':
    app.run(debug=True)
