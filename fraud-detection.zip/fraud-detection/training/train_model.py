import os
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import roc_auc_score, precision_score, recall_score
import torch.nn as nn
import torch.optim as optim
import joblib

base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

data_path = os.path.join(base_dir, 'training/transaction_data.csv')
scaler_path = os.path.join(base_dir, 'models/scaler/scaler.pkl')
model_path = os.path.join(base_dir, 'models/fraud_detection_model.pth')

df = pd.read_csv(data_path)
features = df.iloc[:, :-1]
target = df.iloc[:, -1]

X_train, X_test, y_train, y_test = train_test_split(
    features, target, test_size=0.2, random_state=42, stratify=target
)

minimum, maximum = X_train.min(), X_train.max()
X_train = (X_train - minimum) / (maximum - minimum)
X_test = (X_test - minimum) / (maximum - minimum)

scaler_data = {"min": minimum, "max": maximum}
os.makedirs(os.path.dirname(scaler_path), exist_ok=True)
joblib.dump(scaler_data, scaler_path)

smote = SMOTE(random_state=42)
X_train_resampled, y_train_resampled = smote.fit_resample(X_train, y_train)

X_train_tensor = torch.tensor(X_train_resampled.values, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train_resampled.values, dtype=torch.float32).unsqueeze(1)
X_test_tensor = torch.tensor(X_test.values, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test.values, dtype=torch.float32).unsqueeze(1)

class Model(nn.Module):
    def __init__(self, input_dim):
        super(Model, self).__init__()
        self.layer1 = nn.Linear(input_dim, 128)
        self.bn1 = nn.BatchNorm1d(128)
        self.layer2 = nn.Linear(128, 64)
        self.bn2 = nn.BatchNorm1d(64)
        self.layer3 = nn.Linear(64, 32)
        self.bn3 = nn.BatchNorm1d(32)
        self.layer4 = nn.Linear(32, 1)
        self.dropout = nn.Dropout(p=0.3)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.bn1(self.layer1(x)))
        x = self.dropout(x)
        x = self.relu(self.bn2(self.layer2(x)))
        x = self.dropout(x)
        x = self.relu(self.bn3(self.layer3(x)))
        x = self.dropout(x)
        return self.layer4(x)

input_dim = X_train.shape[1]
model = Model(input_dim)
criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([y_train.value_counts()[0] / y_train.value_counts()[1]]))
optimizer = optim.Adam(model.parameters(), lr=0.001)

num_epochs = 5
batch_size = 128
train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

for epoch in range(num_epochs):
    model.train()
    epoch_loss = 0
    y_true, y_pred = [], []

    for inputs, targets in train_loader:
        outputs = model(inputs).squeeze()
        loss = criterion(outputs, targets.squeeze())
        epoch_loss += loss.item()
        y_true.extend(targets.squeeze().tolist())
        y_pred.extend(torch.sigmoid(outputs).tolist())
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    train_auc = roc_auc_score(y_true, y_pred)
    print(f"Epoch {epoch+1}/{num_epochs}, Loss: {epoch_loss/len(train_loader):.4f}, AUC-ROC: {train_auc:.4f}")

model.eval()
with torch.no_grad():
    test_outputs = model(X_test_tensor).squeeze()
    test_loss = criterion(test_outputs, y_test_tensor.squeeze())
    test_predicted_probs = torch.sigmoid(test_outputs).numpy()
    test_predicted_labels = (test_predicted_probs > 0.5).astype(int)
    test_auc = roc_auc_score(y_test, test_predicted_probs)
    test_precision = precision_score(y_test, test_predicted_labels)
    test_recall = recall_score(y_test, test_predicted_labels)
print(f"Test Loss: {test_loss.item():.4f}")
print(f"Test AUC-ROC: {test_auc:.4f}")
print(f"Test Precision: {test_precision:.4f}")
print(f"Test Recall: {test_recall:.4f}")

os.makedirs(os.path.dirname(model_path), exist_ok=True)
torch.save(model.state_dict(), model_path)
