from flask import Blueprint, request, jsonify, render_template, current_app, send_file, redirect
from werkzeug.utils import secure_filename
import os
import pandas as pd
from .models import db, Transaction
from .model import predict_fraud
from . import db
import sqlite3
import io

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def home():
    return redirect('/manual')

@main_bp.route('/manual', methods=['GET'])
def manual():
    return render_template('manual.html')

@main_bp.route('/manual/predict', methods=['POST'])
def manual_predict():
    distance_from_home = float(request.form['distance_from_home'])
    distance_from_last_transaction = float(request.form['distance_from_last_transaction'])
    ratio_to_median_purchase_price = float(request.form['ratio_to_median_purchase_price'])
    repeat_retailer = bool(int(request.form['repeat_retailer']))
    used_chip = bool(int(request.form['used_chip']))
    used_pin_number = bool(int(request.form['used_pin_number']))
    online_order = bool(int(request.form['online_order']))

    input_data = {
        "distance_from_home": distance_from_home,
        "distance_from_last_transaction": distance_from_last_transaction,
        "ratio_to_median_purchase_price": ratio_to_median_purchase_price,
        "repeat_retailer": repeat_retailer,
        "used_chip": used_chip,
        "used_pin_number": used_pin_number,
        "online_order": online_order
    }

    prediction = predict_fraud(input_data)
    is_fraudulent = prediction['is_fraudulent']
    probability = prediction['probability']

    transaction = Transaction(
        distance_from_home=distance_from_home,
        distance_from_last_transaction=distance_from_last_transaction,
        ratio_to_median_purchase_price=ratio_to_median_purchase_price,
        repeat_retailer=repeat_retailer,
        used_chip=used_chip,
        used_pin_number=used_pin_number,
        online_order=online_order,
        is_fraudulent=is_fraudulent,
        probability=probability
    )

    with current_app.app_context():
        db.session.add(transaction)
        db.session.commit()

    result = "Fraud detected!" if is_fraudulent else "Not fraud"
    confidence = round(probability * 100, 2)

    return render_template('manual.html', prediction=result, confidence=confidence)

@main_bp.route('/predict', methods=['POST'])
def api_predict():
    data = request.get_json()
    prediction = predict_fraud(data)

    transaction = Transaction(
        distance_from_home=data['distance_from_home'],
        distance_from_last_transaction=data['distance_from_last_transaction'],
        ratio_to_median_purchase_price=data['ratio_to_median_purchase_price'],
        repeat_retailer=bool(data['repeat_retailer']),
        used_chip=bool(data['used_chip']),
        used_pin_number=bool(data['used_pin_number']),
        online_order=bool(data['online_order']),
        is_fraudulent=prediction['is_fraudulent'],
        probability=prediction['probability']
    )

    with current_app.app_context():
        db.session.add(transaction)
        db.session.commit()

    return jsonify({
        "is_fraudulent": prediction['is_fraudulent'],
        "probability": prediction['probability']
    })


@main_bp.route('/upload_csv', methods=['POST'])
def upload_csv():
    if 'file' not in request.files:
        current_app.logger.error("No file part in the request.")
        return render_template('error.html', error_message="No file part in the request", show_back=True)

    file = request.files['file']

    if file.filename == '':
        current_app.logger.error("No selected file.")
        return render_template('error.html', error_message="No file selected", show_back=True)

    if not file.filename.lower().endswith('.csv'):
        current_app.logger.error("Invalid file format.")
        return render_template('error.html', error_message="Invalid file format. Please upload a CSV file.", show_back=True)

    filename = secure_filename(file.filename)
    filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)

    os.makedirs(current_app.config['UPLOAD_FOLDER'], exist_ok=True)

    try:
        file.save(filepath)
        current_app.logger.info(f"File saved successfully at {filepath}")
    except Exception as e:
        current_app.logger.error(f"Error saving file: {str(e)}")
        return render_template('error.html', error_message=f"Error saving file: {str(e)}", show_back=True)

    try:
        data = pd.read_csv(filepath)

        EXPECTED_COLUMNS = 7
        if data.shape[1] != EXPECTED_COLUMNS:
            error_message = f"Incorrect file dimensions. Expected {EXPECTED_COLUMNS} columns, but got {data.shape[1]}."
            current_app.logger.error(error_message)
            return render_template('error.html', error_message=error_message, show_back=True)

        predictions = []

        with current_app.app_context():
            for _, row in data.iterrows():
                input_data = row.to_dict()
                prediction = predict_fraud(input_data)

                transaction = Transaction(
                    distance_from_home=input_data['distance_from_home'],
                    distance_from_last_transaction=input_data['distance_from_last_transaction'],
                    ratio_to_median_purchase_price=input_data['ratio_to_median_purchase_price'],
                    repeat_retailer=bool(input_data['repeat_retailer']),
                    used_chip=bool(input_data['used_chip']),
                    used_pin_number=bool(input_data['used_pin_number']),
                    online_order=bool(input_data['online_order']),
                    is_fraudulent=prediction['is_fraudulent'],
                    probability=prediction['probability']
                )

                db.session.add(transaction)

                predictions.append({
                    **input_data,
                    "is_fraudulent": prediction['is_fraudulent'],
                    "probability": prediction['probability']
                })

            db.session.commit()

        results_filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], 'predictions.csv')
        results_df = pd.DataFrame(predictions)
        results_df.to_csv(results_filepath, index=False)

        current_app.logger.info("Predictions processed and transactions saved successfully.")
        return render_template('predictions.html', predictions=predictions)

    except Exception as e:
        current_app.logger.error(f"Error processing file: {str(e)}")
        return render_template('error.html', error_message=f"Error processing file: {str(e)}", show_back=True)

@main_bp.route('/show_data', methods=['GET'])
def show_data():
    try:
        transactions = Transaction.query.all()

        data = [
            {
                'id': transaction.id,
                'distance_from_home': transaction.distance_from_home,
                'distance_from_last_transaction': transaction.distance_from_last_transaction,
                'ratio_to_median_purchase_price': transaction.ratio_to_median_purchase_price,
                'repeat_retailer': transaction.repeat_retailer,
                'used_chip': transaction.used_chip,
                'used_pin_number': transaction.used_pin_number,
                'online_order': transaction.online_order,
                'is_fraudulent': transaction.is_fraudulent,
                'probability': transaction.probability
            }
            for transaction in transactions
        ]

        return render_template('show_data.html', data=data)

    except Exception as e:
        current_app.logger.error(f"Error retrieving data: {str(e)}")
        return render_template('error.html', error_message=f"Error retrieving data: {str(e)}", show_back=True)
    

@main_bp.route('/download_data', methods=['GET'])
def download_data():
    try:
        transactions = Transaction.query.all()

        data = [
            {
                'id': transaction.id,
                'distance_from_home': transaction.distance_from_home,
                'distance_from_last_transaction': transaction.distance_from_last_transaction,
                'ratio_to_median_purchase_price': transaction.ratio_to_median_purchase_price,
                'repeat_retailer': transaction.repeat_retailer,
                'used_chip': transaction.used_chip,
                'used_pin_number': transaction.used_pin_number,
                'online_order': transaction.online_order,
                'is_fraudulent': transaction.is_fraudulent,
                'probability': transaction.probability
            }
            for transaction in transactions
        ]

        df = pd.DataFrame(data)
        csv_file = io.StringIO()
        df.to_csv(csv_file, index=False)
        csv_file.seek(0)

        return send_file(io.BytesIO(csv_file.getvalue().encode()), 
                         mimetype='text/csv', 
                         as_attachment=True, 
                         download_name='transaction_data.csv')
    
    except Exception as e:
        current_app.logger.error(f"Error generating CSV: {str(e)}")
        return render_template('error.html', error_message=f"Error generating CSV: {str(e)}", show_back=True)


@main_bp.route('/manual')
def manual_screen():
    return render_template('manual.html')
