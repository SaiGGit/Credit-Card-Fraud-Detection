from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Transaction(db.Model):
    __tablename__ = 'transactions'
    id = db.Column(db.Integer, primary_key=True)
    distance_from_home = db.Column(db.Float, nullable=False)
    distance_from_last_transaction = db.Column(db.Float, nullable=False)
    ratio_to_median_purchase_price = db.Column(db.Float, nullable=False)
    repeat_retailer = db.Column(db.Boolean, nullable=False)
    used_chip = db.Column(db.Boolean, nullable=False)
    used_pin_number = db.Column(db.Boolean, nullable=False)
    online_order = db.Column(db.Boolean, nullable=False)
    is_fraudulent = db.Column(db.Boolean, nullable=False)
    probability = db.Column(db.Float, nullable=False)
