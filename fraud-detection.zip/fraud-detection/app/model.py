import torch
import pandas as pd
import joblib
from torch import nn
import os

class Model(nn.Module):
    def __init__(self, input_dim):
        super(Model, self).__init__()
        self.layer1 = nn.Linear(input_dim, 128)
        self.bn1 = nn.BatchNorm1d(128)
        self.layer2 = nn.Linear(128, 64)
        self.bn2 = nn.BatchNorm1d(64)
        self.layer3 = nn.Linear(64, 32)
        self.bn3 = nn.BatchNorm1d(32)
        self.layer4 = nn.Linear(32, 1)
        self.dropout = nn.Dropout(p=0.3)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.bn1(self.layer1(x)))
        x = self.dropout(x)
        x = self.relu(self.bn2(self.layer2(x)))
        x = self.dropout(x)
        x = self.relu(self.bn3(self.layer3(x)))
        x = self.dropout(x)
        return self.layer4(x)

def load_model(model_path):
    model = Model(input_dim=7)
    model.load_state_dict(torch.load(model_path))
    model.eval()
    return model

def predict_fraud(input_data):
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    print("Base directory:", base_dir)
    
    input_df = pd.DataFrame([input_data])

    scaler_path = os.path.join(base_dir, 'models/scaler/scaler.pkl')
    if not os.path.exists(scaler_path):
        raise FileNotFoundError(f"Scaler file not found at: {scaler_path}")
    scaler = joblib.load(scaler_path)

    min_vals = scaler['min']
    max_vals = scaler['max']
    normalized_data = (input_df - min_vals) / (max_vals - min_vals)

    input_tensor = torch.tensor(normalized_data.values, dtype=torch.float32)

    model_path = os.path.join(base_dir, 'models/fraud_detection_model.pth')
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found at: {model_path}")
    model = load_model(model_path)

    with torch.no_grad():
        logits = model(input_tensor).squeeze()
        probability = torch.sigmoid(logits).item()

    is_fraudulent = probability > 0.5
    return {"is_fraudulent": is_fraudulent, "probability": probability}
