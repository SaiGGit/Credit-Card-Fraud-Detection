from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Transaction(db.Model):
    __tablename__ = 'transactions'
    id = db.Column(db.Integer, primary_key=True)
    transaction_data = db.Column(db.JSON)
    prediction = db.Column(db.Boolean)

def init_db():
    db.create_all()
